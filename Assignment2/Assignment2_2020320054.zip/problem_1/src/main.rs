use problem_1::interact_module::gaming;
fn main() {
    gaming();
}
